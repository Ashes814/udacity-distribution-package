from setuptools import setup


setup(name='ashesdistribution', 
      version = '0.0.1', 
      description='This is a homework package in Udacity', 
      packages=['ashesdistribution'])